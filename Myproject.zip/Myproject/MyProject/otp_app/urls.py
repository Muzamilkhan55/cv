from django.urls import path
from . import views 

urlpatterns = [
    path("", views.index, name="index"),
    path('verify-email/<str:username>/', views.verify_email, name='verify-email'),
    path('register/', views.signup, name='signup'), 
    path("resend-otp", views.resend_otp, name="resend-otp"),
    path("login", views.signin, name="signin"),
    path("logout", views.logout, name="logout"), 
    path('admin/login/', views.admin_login, name='admin_login'),
    path('health_dashboard/', views.health_dashboard, name='health_dashboard'),
    path('main_symptoms_information/', views.main_symptoms_info, name='main_symptoms_information'),
    path('user_symptoms/', views.user_symptoms, name='user_symptoms'),
    path('conditions_symptoms/', views.conditions_symptoms, name='conditions_symptoms'),
    path('conditions_details_5/', views.conditions_details_5, name='conditions_details_5'),
    path('condition_details_6/', views.condition_details_6, name='condition_details_6'),
    path('Treatment_feedback_7/', views.Treatment_feedback_7, name='Treatment_feedback_7'),
]
