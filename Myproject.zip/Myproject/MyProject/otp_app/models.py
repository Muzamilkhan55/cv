from django.db import models
from django.contrib.auth.models import AbstractUser
from django.conf import settings
import secrets


class CustomUser(AbstractUser):
    email = models.EmailField(unique=True)
    
    USERNAME_FIELD = 'email'  # Use a string here, not a tuple
    REQUIRED_FIELDS = ['username']

    def __str__(self):  # Corrected method name
        return self.email

class OtpToken(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="otps")
    otp_code = models.CharField(max_length=6, unique=True)
    otp_created_at = models.DateTimeField(auto_now_add=True)
    otp_expires_at = models.DateTimeField(blank=True, null=True)

    def save(self, *args, **kwargs):
        if not self.otp_code:  # Generate OTP code if not provided
            # self.otp_code = secrets.token_hex(3)  # Generate a random 6-character OTP code
            self.otp_code = str(secrets.randbelow(10**6)).zfill(6)  # Ensures 6-digit format
        super().save(*args, **kwargs)
