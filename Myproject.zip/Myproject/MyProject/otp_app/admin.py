# otp_app/admin.py
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import CustomUser

class CustomUserAdmin(UserAdmin):
    # Display these fields in the user list view
    list_display = ('username', 'email', 'first_name', 'last_name', 'is_active', 'date_joined')
    # Add search fields
    search_fields = ('username', 'email', 'first_name', 'last_name')
    # Define fields that can be used to filter users
    list_filter = ('is_active', 'is_staff', 'date_joined')
    # Organize fields for the detailed user form view
    fieldsets = (
        (None, {'fields': ('username', 'password')}),
        ('Personal info', {'fields': ('first_name', 'last_name', 'email')}),
        ('Permissions', {'fields': ('is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions')}),
        ('Important dates', {'fields': ('last_login', 'date_joined')}),
    )
    # Fields when adding a new user in admin
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('username', 'email', 'first_name', 'last_name', 'password1', 'password2'),
        }),
    )

# Register the CustomUser model with the admin panel
admin.site.register(CustomUser, CustomUserAdmin)
