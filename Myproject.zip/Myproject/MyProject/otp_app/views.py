from django.shortcuts import render, redirect, get_object_or_404
from .forms import RegisterForm
from .models import OtpToken, CustomUser
from django.contrib import messages
from django.contrib.auth import get_user_model, authenticate, login, logout as auth_logout
from django.utils import timezone
from django.core.mail import send_mail
import logging
from django.conf import settings
from django.db import IntegrityError
from django.contrib.auth.decorators import login_required

# Set up logging
logger = logging.getLogger(__name__)

# Index View
def index(request):
    return render(request, "index.html")

# Signup View
def signup(request):
    form = RegisterForm()
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            try:
                user = form.save(commit=False)
                user.is_active = False
                user.save()

                otp = OtpToken.objects.create(
                    user=user,
                    otp_expires_at=timezone.now() + timezone.timedelta(minutes=5)
                )

                send_otp_email(user, otp.otp_code)
                messages.success(request, "Welcome to Learn Medi! Your account has been created. An OTP has been sent to your email for verification.")
                return redirect("verify-email", username=user.username)
            except IntegrityError:
                messages.error(request, "An error occurred while creating the account. Please try again.")
                return render(request, "signup.html", {"form": form})

    context = {"form": form}
    return render(request, "signup.html", context)

# Function to send OTP email
def send_otp_email(user, otp_code):
    subject = "Verify Your Account - OTP"
    message = f"""
        Hi {user.username},
        Here is your OTP for account activation: {otp_code}.
        It expires in 5 minutes. To verify, please go to:
        http://127.0.0.1:8000/verify-email/{user.username}
    """
    sender = settings.DEFAULT_FROM_EMAIL
    receiver = [user.email]

    send_mail(subject, message, sender, receiver, fail_silently=False)

# Verify Email (OTP) View
def verify_email(request, username):
    User = get_user_model()
    user = User.objects.get(username=username)
    user_otp = OtpToken.objects.filter(user=user).last()  # Fetch the latest OTP

    if request.method == 'POST':
        input_otp = request.POST.get('otp_code')

        # Log the OTP for debugging purposes
        logger.debug(f"Input OTP: {input_otp}")
        logger.debug(f"Stored OTP: {user_otp.otp_code if user_otp else 'No OTP found'}")

        # Check if OTP is correct and not expired
        if user_otp and user_otp.otp_code == input_otp:
            if user_otp.otp_expires_at > timezone.now():
                user.is_active = True  # Activate user
                user.save()
                messages.success(request, "Account activated! You can now log in.")
                return redirect("signin")
            else:
                messages.warning(request, "OTP has expired. Please request a new one.")
        else:
            messages.warning(request, "Invalid OTP. Please try again.")

    context = {"username": username}
    return render(request, "verify_token.html", context)

# Logout View
def logout(request):
    auth_logout(request)
    messages.success(request, "You have been logged out successfully!")
    return redirect("signin")

# Resend OTP View
def resend_otp(request):
    if request.method == 'POST':
        user_email = request.POST.get("otp_email")

        user = get_user_model().objects.filter(email=user_email).first()
        if user:
            otp = OtpToken.objects.create(user=user, otp_expires_at=timezone.now() + timezone.timedelta(minutes=5))
            send_otp_email(user, otp.otp_code)
            messages.success(request, "A new OTP has been sent to your email address.")
            logger.info(f"A new OTP has been sent to {user.email}.")
            return redirect("verify-email", username=user.username)
        else:
            messages.warning(request, "This email doesn't exist in the database.")
            logger.warning(f"Attempt to resend OTP for non-existent email: {user_email}")
            return redirect("resend-otp")

    context = {}
    return render(request, "resend_otp.html", context)

# Signin View
def signin(request):
    if request.method == 'POST':
        email = request.POST.get('username')  # Ensure 'username' matches the input name in the HTML form
        password = request.POST.get('password')  # Get password from the form
        user = authenticate(request, username=email, password=password)

        if user is not None:
            if user.is_staff:  # Check if the user is an admin
                login(request, user)
                messages.success(request, f"Hi {user.username}, you are now logged in as admin.")
                return redirect('/admin/')  # Redirecting to the admin dashboard
            else:
                if user.is_active:
                    login(request, user)
                    messages.success(request, f"Hi {user.username}, you are now logged in.")
                    return redirect("health_dashboard")  # Redirect directly to health_dashboard
                else:
                    messages.warning(request, "Account not activated. Please check your email for activation instructions.")
                    return redirect("signin")
        else:
            messages.warning(request, "Invalid credentials.")
            return render(request, "login.html", {'error': "Invalid credentials."})  # Render with an error message

    return render(request, "login.html")

# Admin Login View
def admin_login(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')

        # Authenticate the user
        user = authenticate(request, username=email, password=password)

        if user is not None and user.is_staff:
            login(request, user)
            messages.success(request, f"Welcome, {user.username}. You are now logged in as admin.")
            return redirect('admin_dashboard')  # Redirect to your admin dashboard or home page
        else:
            messages.error(request, "Invalid email or password, or you do not have permission to access this page.")

    return render(request, 'Admin.html')  # Render the admin login page

# Health Dashboard View
@login_required
def health_dashboard(request):
    if not request.user.is_active:
        return redirect('verify-email', username=request.user.username)
    else:
        username = request.user.username  # Get the logged-in user's username
        context = {'username': username}  # Pass it to the template
        return render(request, 'health_Dashboard-1.html', context)


def main_symptoms_info(request):
    return render(request, 'Main_symptoms_information-2.html')

def user_symptoms(request):
    return render(request, 'user_symptoms-3.html')

def conditions_symptoms(request):
    return render(request, 'conditions_symptoms-4.html')

def conditions_details_5(request):
    return render(request, 'conditions_details-5.html')

def conditions_details_5(request):
    return render(request, 'conditions_details-5.html')

def condition_details_6(request):
    return render(request, 'condition_details-6.html')

def Treatment_feedback_7(request):
    return render(request, 'Treatment_feedback-7.html')